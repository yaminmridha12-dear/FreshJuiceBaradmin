package com.freshjuicebar.manager

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

data class Food(val date:String,val item:String,val qty:Double,val cost:Double)
data class Sale(val date:String,val item:String,val qty:Int,val total:Double)
data class Expense(val date:String,val title:String,val amount:Double)

fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
fun money(v:Double)="৳${"%.2f".format(Locale.US,v)}"

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App(this)}}
}

@Composable
fun App(ctx:Context){
 var tab by remember{mutableStateOf(0)}
 var foods by remember{mutableStateOf(listOf<Food>())}
 var sales by remember{mutableStateOf(listOf<Sale>())}
 var expenses by remember{mutableStateOf(listOf<Expense>())}
 var closed by remember{mutableStateOf(setOf<String>())}
 val fc=foods.sumOf{it.cost}; val sl=sales.sumOf{it.total}; val ex=expenses.sumOf{it.amount}; val profit=sl-fc-ex

 MaterialTheme{
  Scaffold(topBar={TopAppBar(title={Column{
   Text("🥤 Fresh Juice Bar Manager")
   Text("Monthly Business Control",style=MaterialTheme.typography.labelSmall)
  }})}){p->
   Column(Modifier.padding(p).padding(12.dp)){
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
     Stat("Food Cost",money(fc),Modifier.weight(1f));Stat("Sales",money(sl),Modifier.weight(1f))
    }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
     Stat("Other",money(ex),Modifier.weight(1f));Stat("Net Profit",money(profit),Modifier.weight(1f))
    }
    Spacer(Modifier.height(10.dp))
    TabRow(selectedTabIndex=tab){
     listOf("Dashboard","Food Cost","Sales","Closing").forEachIndexed{i,n->Tab(tab==i,{tab=i},text={Text(n)})}
    }
    Spacer(Modifier.height(10.dp))
    when(tab){
     0->Dashboard(foods,sales,expenses,closed)
     1->FoodScreen{foods=foods+it}
     2->SalesScreen{sales=sales+it}
     3->ClosingScreen(closed){closed=closed+it}
    }
   }
  }
 }
}

@Composable fun Stat(t:String,v:String,m:Modifier){Card(m){Column(Modifier.padding(12.dp)){Text(t,style=MaterialTheme.typography.labelMedium);Text(v,style=MaterialTheme.typography.titleLarge)}}}

@Composable fun Dashboard(f:List<Food>,s:List<Sale>,e:List<Expense>,c:Set<String>){
 val days=(f.map{it.date}+s.map{it.date}+e.map{it.date}+c).distinct().sorted().reversed()
 LazyColumn{
  item{Text("Daily Records",style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(8.dp))}
  if(days.isEmpty())item{Text("No records yet.")}
  items(days){d->
   val a=s.filter{it.date==d}.sumOf{it.total};val b=f.filter{it.date==d}.sumOf{it.cost};val x=e.filter{it.date==d}.sumOf{it.amount}
   Card(Modifier.fillMaxWidth().padding(vertical=3.dp)){Column(Modifier.padding(10.dp)){
    Text("$d  ${if(c.contains(d))"✓ Closed" else "Open"}")
    Text("Sale ${money(a)}   Food ${money(b)}   Other ${money(x)}")
    Text("Net Profit ${money(a-b-x)}")
   }}
  }
 }
}

@Composable fun FoodScreen(add:(Food)->Unit){
 var item by remember{mutableStateOf("")};var qty by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")}
 Column{
  Text("Food Costing",style=MaterialTheme.typography.titleLarge)
  Field("Item",item){item=it};Field("Quantity",qty){qty=it};Field("Purchase Cost ৳",cost){cost=it}
  Button(onClick={val c=cost.toDoubleOrNull();if(item.isNotBlank()&&c!=null){add(Food(today(),item,qty.toDoubleOrNull()?:0.0,c));item="";qty="";cost=""}},Modifier.fillMaxWidth()){Text("Add Food Cost")}
 }
}

@Composable fun SalesScreen(add:(Sale)->Unit){
 var item by remember{mutableStateOf("")};var qty by remember{mutableStateOf("")};var price by remember{mutableStateOf("")}
 Column{
  Text("Sales",style=MaterialTheme.typography.titleLarge)
  Field("Juice / Shake",item){item=it};Field("Quantity Sold",qty){qty=it};Field("Price per Unit ৳",price){price=it}
  Button(onClick={val q=qty.toIntOrNull();val p=price.toDoubleOrNull();if(item.isNotBlank()&&q!=null&&p!=null){add(Sale(today(),item,q,q*p));item="";qty="";price=""}},Modifier.fillMaxWidth()){Text("Add Sale")}
 }
}

@Composable fun ClosingScreen(closed:Set<String>,close:(String)->Unit){
 val d=today()
 Column{
  Text("Daily Closing",style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(8.dp));Text("Today: $d");Spacer(Modifier.height(8.dp))
  if(closed.contains(d))Text("✓ Closing completed")
  else Button(onClick={close(d)},Modifier.fillMaxWidth()){Text("Complete Closing")}
 }
}

@Composable fun Field(label:String,value:String,onChange:(String)->Unit){
 OutlinedTextField(value,onChange,label={Text(label)},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(6.dp))
}
