Fresh Juice Bar Manager v1
Build: open this project in a compatible Android build environment, sync Gradle, then Build APK.
Included: Food Costing, Sales, Net Profit, Other Expense model, Daily Closing, Daily records.
This v1 is local/in-memory UI prototype. Cloud owner/staff sync is a later backend step.
